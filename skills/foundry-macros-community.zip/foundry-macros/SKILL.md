---
name: foundry-macros
description: Create, improve, or troubleshoot Foundry VTT JavaScript macros, especially dnd5e spell macros with interactive targeting, readable roll cards, and Sequencer/JB2A animations. Use compact Ukrainian UI and the bundled Chromatic Orb design reference.
---

# Foundry macros

Build usable Script macros and importable Macro JSON. This is a portable community skill for Foundry VTT 14 / dnd5e 6.x. Current requests take precedence. It does not authorize installing modules, changing world settings, or editing unrelated module code.

## Reading this skill from a chat link

Use these instructions for the user's macro request; no local skill installation is required to read them. Follow the linked references relevant to the task before generating code. If a linked file cannot be accessed, say which file is missing and ask for that file or the skill ZIP; do not claim to have read inaccessible examples. User instructions take precedence over these defaults.

Direct source links for web readers:

- [UI and interaction](https://raw.githubusercontent.com/funteaqueue/funtomations/main/skills/foundry-macros/references/ui-design.md)
- [Module API and limitations](https://raw.githubusercontent.com/funteaqueue/funtomations/main/skills/foundry-macros/references/fantik-automations.md)
- [Example selection](https://raw.githubusercontent.com/funteaqueue/funtomations/main/skills/foundry-macros/references/examples.md)
- [Chromatic Orb v3.1 source](https://raw.githubusercontent.com/funteaqueue/funtomations/main/skills/foundry-macros/assets/chromatic-orb.js)
- [Implementation details](https://raw.githubusercontent.com/funteaqueue/funtomations/main/skills/foundry-macros/references/implementation.md)
- [Dice So Nice lifecycle](https://raw.githubusercontent.com/funteaqueue/funtomations/main/skills/foundry-macros/references/dice-lifecycle.md)

## Module and examples

Optional companion: [Fantik’s Automations](https://github.com/funteaqueue/funtomations).
Read its [README](https://github.com/funteaqueue/funtomations/blob/main/README.md) for installation and player features, and [references/fantik-automations.md](references/fantik-automations.md) for the versioned macro API. Module version and API version are different numbers: this package documents module 0.8.4 / spellCards API 5.
Read [references/examples.md](references/examples.md) to choose a suitable example and understand which parts are current or historical. Do not treat every bundled macro as a fully compliant template.

## Default design and interaction

Visual references supplied by the user: [main panel](assets/chromatic-orb-panel.png) and [expanded settings](assets/chromatic-orb-settings.png). View these images before designing macro UI; read the screenshot guidance in [ui-design.md](references/ui-design.md). Adapt the controls to the requested mechanic rather than copying spell-specific fields.


**Compactness is the highest UI priority.** Put related controls and values on one row whenever they remain readable. Show each fact once. Move details that need not be permanently visible into hover tooltips; retain their accessible names/focus equivalents. Add no unnecessary labels, explanatory text, repeated headings, or status summaries. Before delivery, remove any row or text that can be merged, deduplicated, or moved into a tooltip. Apply this to cards, pickers, and settings alike; the example asset is not a reason to preserve redundant content.

**Use the accepted Chromatic Orb design as the default for new macros.** Before creating or changing UI, read [references/ui-design.md](references/ui-design.md). It defines the shared layout, cursor, roll tooltips, artwork, and interaction conventions. Adapt the spell's theme and mechanics within that design; do not ask the user to repeat these preferences. A current request can override any default.

The current reference implementation is [assets/chromatic-orb.js](assets/chromatic-orb.js). It supersedes the historical Eldritch Blast example for visual design and UI. Use its relevant helpers rather than copying Chromatic Orb's targeting limits, damage, or bounce rules into other spells.

## Clarify an incomplete request

If the player has not provided enough information to implement the intended macro, ask concise questions before deciding the missing behavior. Do not invent mechanics, house rules, resource costs, target restrictions, or the desired level of automation. Ask only about gaps that materially affect the result: for example the rules edition or exact feature text, custom changes, targeting, resource consumption, or whether a result should be rolled, displayed, or applied.

Use the conversation and accessible environment first; do not ask for information already supplied or inspectable. Group the essential questions into one short message, offer clear choices when helpful, and wait for answers before implementing the dependent behavior. Independent inspection or preparation may continue. For minor visual details, use the compact, immersive design defaults rather than making the player answer a long questionnaire. Briefly restate the agreed behavior when the answers resolve a significant ambiguity.

## Start with the actual environment

**Current required target: Foundry VTT 14 / dnd5e 6.x.** The user has upgraded both. Build new macros for this combination; do not add legacy dnd5e 5.3.3 or Foundry 13 branches unless explicitly requested. Verify exact installed builds when using version-sensitive APIs; do not assume a particular patch is the latest release.

Distinguish **Foundry version**, **game-system version**, and **D&D rules edition**. Inspect available manifests and relevant installed API implementations. Installed modules may be inactive in the current world. Ask for missing versions only when they change the implementation and cannot be determined locally.

The bundled example targets Foundry 14 / dnd5e 6.0.3. Its APIs and HTML sanitization were checked against local source; behavior was tested with mocks and a browser preview, not an end-to-end live cast. Do not advertise it as tested on dnd5e 5.3.3 or Foundry 13.

## Casting must remain available

**A macro is a play aid, not a rules gatekeeper. Always provide a usable path to cast, at least as a styled chat card.** Missing spell/item/feature documents, ambiguous activities, exhausted resources, unprepared spells, missing targets/tokens/scenes, or unavailable helper modules must not cause a dead-end refusal. Do not add prerequisite checks unless they are needed for the operation the user actually chose. This rule supersedes older examples that stop on those conditions.

- Standalone macros do not require the spell/item/feature to exist on the character sheet. Use supplied context when available; otherwise use macro settings and compact editable inputs for casting level and damage. Spell attack bonuses and spell save DC come automatically from the resolved caster as described below; manual entry is only a fallback when those data cannot be resolved. Do not force an item/activity selection merely to cast or roll damage. Missing or ambiguous bindings disable automatic lookup/consumption, not casting.
- Separate **casting level** from **resource consumption**. Offer a compact switch **«Списати чарунку»** beside the level choice (or **«Списати ресурси»** for items/features). Keep applicable casting levels selectable even with zero slots. Default consumption on when the resource is resolved and available; otherwise default it off with a brief inline explanation. Unchecked means no resource mutation, while the chosen level still controls scaling and stored spell state. Never require the player to edit code, restore slots, or install a module to proceed.
- When consumption is selected, use the actual bound item/activity configuration if available, or the explicitly selected character slot/resource for a standalone macro. Preserve Pact Magic, upcasting, charges, and linked resources. Consume exactly once; do not duplicate native consumption or charge again per beam, subsequent attack, or damage button unless specifically required. Pre-commit cancellation spends nothing. Do not drive resource counts negative.
- If selected consumption becomes unavailable or fails, keep the user's inputs and offer **«Кастувати без списання»** immediately. Do not silently claim that a resource was spent. An uncertain update must not be blindly retried; allow casting with manual resource bookkeeping. Resource validation protects the deduction, not the ability to cast.
- If actor data, scene access, or automation is unavailable, retain manual values and an obvious **«Лише картка в чат»** path. Omit unsupported automation without inventing rolls, targets, HP changes, or successful effects. Respect actual Foundry permissions: do not bypass document access; explain genuine API failures and preserve a retry/manual path rather than adding artificial restrictions. Explicit Cancel/Esc still cancels.

## Default interaction and presentation

- Use Ukrainian user-facing text. Keep spell names recognizable.
- **Keep card and dialog text minimal.** Unless explicitly requested, do not add flavor prose, invented quotes/taglines, the spell description/rules text, redundant headings, or explanatory paragraphs. Normally show only the spell name, relevant target, level, roll values/breakdowns, damage type, DC, and necessary controls. Add short actionable hints only when needed to complete the current interaction. Decoration should come from the visual design, not extra text.
- **Resolve the caster from a selected token first, then fall back to `game.user.character`.** Use actor-bearing controlled tokens (`canvas.tokens.controlled`), not targeted enemies (`game.user.targets`). With one selected token, use its actor and that token as the scene origin, including its synthetic actor when unlinked. With several selected tokens, offer a compact caster choice rather than arbitrarily taking the first; keep manual/chat-only use available. With no selected actor-bearing token, use the character assigned to the user. If neither exists, offer manual/chat-only use with the user's speaker. Resolve and retain this caster once per invocation, before target selection: later target clicks must not change the caster. Use the same actor for attack bonuses, save DC, resources, spell state, and chat speaker; never mix selected and assigned character data. Non-spatial macros need not require a token.
- **Read spell attack bonuses and spell save DC directly from the resolved caster on every use (selected token first, assigned character otherwise).** Use the system's prepared spellcasting data/formulas, including the relevant ability, proficiency, actor bonuses, and active effects. Do not hard-code values such as +5 or DC 13, reuse another character's values, or require manual entry when character data are available. This must work without finding the spell Item. Honor an explicitly bound spell/activity source; otherwise select the first available source automatically. Keep an override in settings, without an extra source-selection prompt. Never silently choose the highest bonus. A bound item/activity may supply its explicit spell-specific adjustments using that same character's data. If automatic resolution is unavailable, offer manual values/chat-only use instead of blocking the cast.
- **Whenever a macro requires choosing targets, provide click-to-select targeting on the scene.** Do not rely only on preselected targets or a dropdown. Match uniqueness, repetition, count, and completion rules to the spell. For multi-beam spells, each click assigns one beam and repeated clicks on the same token are valid.
- **Every spell, feature, or item macro with target selection must also support use without targets.** Add a small **«Без цілі»** button to the picker for social scenes and other untargeted uses; keep untargeted/manual use accessible even without a loaded scene. This is a committed use, not cancellation: respect the consumption checkbox and preserve applicable rolls, Dice So Nice completion, and the themed result card. Explicitly clear this invocation's target assignments, including any partial selection; never substitute preselected or controlled tokens. Do not query target HP, play effects on a creature, or show target-bound saving throw / Apply Damage controls. If a roll depends on target state, provide a compact manual choice or a clearly indicated default appropriate to that macro; do not invent a target or claim a hit. Preserve and restore the user's previous scene targets as with normal picker cleanup.
- Use the compact picker in [ui-design.md](references/ui-design.md): primary controls on the main panel, infrequent settings behind a gear, horizontal disadvantage/normal/advantage buttons, and an actual aiming mouse cursor over the scene. Show selected/maximum count; represent assignments on the map without duplicating a long target list in the panel. Preserve Undo/Backspace and Cancel/Esc. When the spell permits, queue targets first and start on the last required selection; retain an explicit start action for a shorter queue. Resolve follow-up steps only when their mechanics permit them. Close the picker when finished instead of leaving a terminal result panel open.
- **Use Dice So Nice 3D dice whenever available and enabled, and reveal the result card only after those dice have resolved.** Await a verified completion signal, not an arbitrary delay. Follow the installed module's interactive-roll lifecycle if it determines final results. Do not show the card first or play the same dice again when creating the message. Read [references/dice-lifecycle.md](references/dice-lifecycle.md) for implementation guidance.
- **Preserve every actually rolled die and make its result inspectable.** Show compact totals in the card; put the complete formula, individual die results, struck-through discarded results, and final total in the hover tooltip. Do not duplicate these as permanent rows below the totals. Example: `1d20(<s>5</s> | 14) + 2 + 5 = 21`; damage: `3d8(2 | 3 | 4) = 9`. Retain critical, bonus, rerolled, and exploded dice too. Use actual evaluated Rolls, not reconstructed totals or rerolls. See [ui-design.md](references/ui-design.md) for safe tooltip markup and native-tray roll storage. Do not filter discarded dice out of 3D throws. Respect private/blind visibility.
- In chat, show the target and **attack total beside damage in one compact row**, with dice icons instead of repeated attack/damage/healing labels. Use the actual damage die icon where practical; mixed dice need an unambiguous generic icon. Keep target rows stacked rather than making a wide table. Aim for a 250–270 px chat column, allowing long names without squeezing labels into single letters.
- Strike through dropped dice. For attack rolls, natural **20 / critical success is green**, **1 / critical failure is red**; honor applicable custom critical rules. Color the attack total using only the retained attack d20. A dropped 20 is not a critical hit and must not double damage. Damage totals may use the damage-type accent; never color them as a critical merely because a die rolled its maximum. Do not apply attack critical rules to checks or saves without a system rule.
- Default to manual adjudication: do not infer hit/miss from AC or show hit/miss badges. For damage against recorded targets, provide the GM a native **Apply Damage** workflow where available; HP changes happen only on explicit application, never automatically on cast, render, or save. Preserve native damage types, resistance/immunity handling, and save multipliers. Roll damage for each attack. State actual limits briefly in delivery notes rather than filling the card with technical disclaimers.
- **Use a compact, readable interface that does not break immersion, with artwork and colors appropriate to the macro. The reference screenshots do not prescribe a palette or gold accents.** Follow [ui-design.md](references/ui-design.md). Chromatic Orb uses a multicolored faceted sphere in the card even when its scene effects use one elemental color; do not put that sphere or the historical Eldritch cat on every spell. Use **SVG → encoded image source → `<img>`** for code-native artwork and verify the target sanitizer.
- **Do not add sound to macros unless the user explicitly requests audio.** A spell's description mentioning a bell, thunder, music, or another sound is not an audio request. Use silent visual animations; do not synthesize audio, embed sound assets, or broadcast playback by default.
- Do not assume enemy HP is available to a player's client because a token or its actor exists. For HP-dependent mechanics, use an explicit state choice or an authorized GM-side workflow that returns only the required condition. Do not expose exact hidden HP in chat or socket responses. Automatic local HP inspection should be limited to actors the user may observe.

## Fantik Automations and GM controls

Use the optional API from `game.modules.get('fantik-automations')?.api` when the module is active and the needed capability exists. Read [references/fantik-automations.md](references/fantik-automations.md) for the verified API surface, native dnd5e 6 damage-card shape, GM controls, and known limitations. Recheck local module code before depending on a capability; the reference is a versioned snapshot, and older installations may lack newer helpers. API 4 and later provide generic `spellCards.createCard`, `buildCardData`, and `rollRecordedSave`: pass the ability, DC, recorded targets, and evaluated damage rolls rather than writing a spell-specific GM button.

Prefer the existing standard Apply picker over new custom damage/healing buttons or a module update solely for UI. For targeted damage, retain the exact target token/actor UUIDs and actual evaluated damage rolls so the GM can apply damage to those enemies without the player needing enemy ownership or hidden HP. Prefer native dnd5e damage controls, integrated into the themed card by supported module hooks or provided in a separate native damage card. A player-side macro's click handler alone does not install a working GM-side handler. Do not invent a generic module `applyDamage` method or reuse another spell's metadata to force rendering. Without the module or GM, casting and rolling still work; omit unavailable helper controls and keep native/manual application available. Untargeted casts have no enemy-specific controls.

## Reuse the right parts

- For the current visual reference, read [references/ui-design.md](references/ui-design.md) and adapt the relevant functions in [assets/chromatic-orb.js](assets/chromatic-orb.js). The snapshot is an example, not a generic rules engine; copy it into the task workspace before edits.
- For targeting, re-entry, dice rendering, or animation, read [references/implementation.md](references/implementation.md).
- For the historical reusable example and its limits, read [references/eldritch-example.md](references/eldritch-example.md). Adapt [assets/eldritch-blast.js](assets/eldritch-blast.js) into the task workspace; do not edit the skill's canonical copy for an ordinary new macro. It predates the current caster-resolution and explicit Dice So Nice completion requirements: update those parts before reusing it as a new macro.
- Keep spell-specific rules separate from shared UI. Do not copy Eldritch Blast's beam count, damage, critical treatment, or dependencies into an unrelated spell without checking its mechanics.

## Deliver and verify

Prefer a self-contained `.js` plus importable `.json` under the current task's output directory unless the user chooses another location. Build both from the same command text with:

```text
python <skill-dir>/scripts/package_macro.py <macro.js> --name "Macro name" [--output <macro.json>]
```

This script serializes the macro; it does not verify its JavaScript or Foundry compatibility. Do not write directly to live world database files. If live import is not part of the task, provide links and brief import/paste instructions without claiming installation.

Verify behavior that changed: selected-token priority, assigned-character fallback, multiple-token caster choice, consistent synthetic-actor data, caster stability during target selection, boundary levels, repeated targets, retained/dropped dice, critical damage, cancellation, scene teardown, and lock cleanup where relevant. For dice integration, check that no result card appears before completion, every evaluated die is retained, and the message does not trigger a duplicate throw. For visual changes, inspect the actual generated chat markup at narrow width in a browser, and check the target Foundry sanitizer when embedding media. Mock tests and preview screenshots are not a live Foundry execution.

For resource-dependent macros, verify that selected consumption deducts exactly once, unchecked consumption casts without mutation, and zero slots or missing bindings still allow the selected level and a cast/chat card. Verify that a deduction failure offers continuation without spending, pre-commit cancellation spends nothing, and native consumption is not duplicated. Cover linked resources and casting-level choices when applicable. Missing actors, tokens, scenes, and optional modules must have a manual/chat fallback instead of a prerequisite error.

For target pickers, verify that **«Без цілі»** completes without a target, including after partial selection or a pending target-state lookup, produces no unintended creature effects or target-bound controls, and respects the consumption checkbox without duplicate spending.

The historical Eldritch example's regression harness is available as `node <skill-dir>/scripts/test_eldritch_example.cjs`; use it when adapting relevant logic, not as proof for unrelated mechanics. Missing animation assets should not lose the roll results. Regenerate JSON after the last code change and report material limitations accurately.
